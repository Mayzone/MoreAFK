--mod match identifier 2-43
function NetworkPeer:set_ip_verified(state)
	self._ip_verified = state
	self:_chk_flush_msg_queues()

	if state then
		local user = Steam:user(self:ip())
		if user and user:rich_presence("hook_mod_identifier1712_afk") == "1" then
			managers.chat:feed_system_message(ChatManager.GAME, string.format("%s Also got 'More AFK' mod installed!", self:name()))
		end
	end
end

function NetworkAccountSTEAM:_set_presences()
	Steam:set_rich_presence("level", managers.experience:current_level())
	Steam:set_rich_presence("hook_mod_identifier1712_afk", 1)

	if MenuCallbackHandler:is_modded_client() then
		Steam:set_rich_presence("is_modded", 1)
	else
		Steam:set_rich_presence("is_modded", 0)
	end
end

local _orig = BaseNetworkSession.on_load_complete
function BaseNetworkSession:on_load_complete(simulation)
	_orig(self, simulation)
	if not simulation then
		for peer_id, peer in pairs(self._peers) do
			if peer:ip_verified() then
				DelayedCalls:Add("player_"..peer._user_id, 5, function()
					if managers and managers.chat and alive(peer:unit()) and peer then
						local peer = managers.network:session():peer(1)
						local user = Steam:user(peer:ip())
						if user and user:rich_presence("hook_mod_identifier1712_afk") == "1" then
							managers.chat:feed_system_message(ChatManager.GAME, string.format("More AFK detected from %s", peer:name() ) )
						end
					end
				end)
			end
		end
	end
end