if rawget(_G, "CommandManager") then
	if not CommandManager:in_chat() then
		rawset(_G, "CommandManager", nil)
	end
end

if not rawget(_G, "CommandManager") then
	rawset(_G, "CommandManager", {
		config = {},
		history = {},
		modules = {},
		path = "mods/MoreAFK/CommandManager/%s",
		command_prefixes = {"/", "!", "|", "\\"},
	})

	function CommandManager:Addon(paths)
		if type(paths) == "table" then
			for _, path in pairs(paths) do
				dofile(string.format(self.path, path))
			end
			return
		end

		dofile(string.format(self.path, paths))
	end

	function CommandManager:Module(module_name)
		self.modules[module_name] = true
	end

	function CommandManager:prefixes(str)
		for _, prefix in pairs(self.command_prefixes) do
			if string.sub(str, 1, 1) == prefix then
				return true
			end
		end
	end

	function CommandManager:init()
		self:Addon({ "core/Commands.lua", "CustomCommands.lua", "Addons/Globals.lua" })
		self:Module("base")
	end

	CommandManager:init()
end