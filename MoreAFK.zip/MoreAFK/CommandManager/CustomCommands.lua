local C = CommandManager

C:add_command("afk", nil, nil, nil, function(args)
	local toggle_afk = true

	function release_announcement()
		BetterDelayedCalls:Remove("afk_long_persist")
		BetterDelayedCalls:Remove("afk_long_persist2")
		if not alive(managers.player:player_unit()) then
			if orig_func_md then PlayerStandard._determine_move_direction = orig_func_md end
			if C:is_playing() then
				IngameWaitingForRespawnState.request_player_spawn()
			end
			if global_invisible_toggle then
				dofile("mods/MoreAFK/CommandManager/Addons/invisibleplayer.lua")
			end
		end
		managers.chat:send_message(ChatManager.GAME, 1, "has come back and is no longer AFK.")
	end
	
	global_afk_toggle = global_afk_toggle or false
	if not global_afk_toggle then
		if C:is_playing() then
			if (managers.player:current_state() == "standard") and alive(managers.player:player_unit()) then
				managers.chat:send_message(ChatManager.GAME, 1, "has gone AFK. He will not be a targeted by enemies while gone.")
				if not global_invisible_toggle then
					dofile("mods/MoreAFK/CommandManager/Addons/invisibleplayer.lua")
				end
				if not orig_func_md then orig_func_md = PlayerStandard._determine_move_direction end
				function PlayerStandard:_determine_move_direction(...)
					orig_func_md(self, ...)
					if self._move_dir or self._normal_move_dir
					or (self._controller:get_input_bool("primary_attack")) 
					--or (self._controller:get_input_bool("secondary_attack")) 
					--or (self._controller:get_input_pressed("throw_grenade"))
					--or (self._controller:get_input_pressed("duck"))
					or (self._controller:get_input_pressed("reload")) 
					or (self._controller:get_input_pressed("switch_weapon")) 
					or (self._controller:get_input_pressed("jump")) 
					or (self._controller:get_input_pressed("interact")) 
					or (self._controller:get_input_pressed("use_item")) 
					or (self._controller:get_input_pressed("melee")) then
						if toggle_afk then
							if global_invisible_toggle then
								dofile("mods/MoreAFK/CommandManager/Addons/invisibleplayer.lua")
							end
							toggle_afk = false
							global_afk_toggle = not global_afk_toggle
							release_announcement()
						end
					end
				end
				BetterDelayedCalls:Add("afk_long_persist", 120, function() 
					managers.chat:send_message(ChatManager.GAME, 1, "has been AFK more then 2min. 8min left before going to jail.")
					BetterDelayedCalls:Add("afk_long_persist2", 480, function() 
						local player = managers.player:local_player()
						managers.player:force_drop_carry()
						managers.statistics:downed({death = true})
						IngameFatalState.on_local_player_dead()
						game_state_machine:change_state_by_name("ingame_waiting_for_respawn")
						player:character_damage():set_invulnerable(true)
						player:character_damage():set_health(0)
						player:base():_unregister()
						player:base():set_slot(player, 0)
						managers.chat:send_message(ChatManager.GAME, 1, "has been jailed for AFKing and will be released when back.")
					end, false)
				end, false)
			else
				global_afk_toggle = not global_afk_toggle
				managers.chat:_receive_message(1, "AFK", "Can only be used when masked.", tweak_data.system_chat_color)
			end
		else
			managers.chat:send_message(ChatManager.GAME, 1, "has gone AFK.")
		end
	else
		if C:is_playing() and turn_off_wlk and global_invisible_toggle then
			dofile("mods/MoreAFK/CommandManager/Addons/invisibleplayer.lua")
		end
		release_announcement()
	end
	global_afk_toggle = not global_afk_toggle
end)

C:add_command("h", nil, nil, nil, function(args)
	local index = tonumber(args[1]) or 1
	if index and (index >= 1) then
		local msg_table = {}
		if (index == 1) then
			managers.chat:feed_system_message(ChatManager.GAME, string.format("To use the commands you must apply either of these signs ( %s %s %s )", C.command_prefixes[1], C.command_prefixes[2], C.command_prefixes[3]))
			table.insert(msg_table, "Every command can have diffrent amount of arguments, arguments are not always needed.")
			table.insert(msg_table, "More commands: !h 2")
		elseif (index > 2) then
			table.insert(msg_table, string.format("Page: %d", index))
			table.insert(msg_table, string.format("Invalid page selected, must be 1 to 2", index))
		elseif (index == 2) then
			table.insert(msg_table, string.format("Page: %d/2 - General", index))
			table.insert(msg_table, string.format("!afk"))
		end
		for _,data in pairs(msg_table) do
			local msgfilter = string.gsub(data, "!", C.command_prefixes[1])
			managers.chat:feed_system_message(ChatManager.GAME, string.format(msgfilter))
		end
	end
end)

C:Module("Commands")