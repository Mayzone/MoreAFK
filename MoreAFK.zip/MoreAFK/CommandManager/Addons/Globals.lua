function CommandManager:in_chat()
	if managers.hud._chat_focus == true then
		return true
	end
	if ( managers.network.account and managers.network.account._overlay_opened ) then
		return true
	end
end

function CommandManager:in_game()
	if not game_state_machine then
		return false
	else
		return string.find(game_state_machine:current_state_name(), "game")
	end
end

function CommandManager:is_playing()
	return BaseNetworkHandler._gamestate_filter.any_ingame_playing[game_state_machine.last_queued_state_name(game_state_machine)]
end

function can_interact()
	return true
end

function CommandManager:message(text, title)
	if text and type(text) == "string" then
		managers.chat:_receive_message(1, (title:upper() or "SYSTEM"), text, tweak_data.system_chat_color)
		if CommandManager.config then
			CommandManager:Save()
		end
	end
end

function CommandManager:Send_Message(peer_id, message)
	if not message or message == "" then
		return
	end

	local peer = managers.network:session():peer(peer_id)
	if peer_id == managers.network:session():local_peer():id() then 
		managers.chat:feed_system_message(ChatManager.GAME, message)
	else
		if peer then
			managers.network:session():send_to_peer(peer, "send_chat_message", 1, message)
		end
	end
end

function string.startswith(String, Start)
	return string.sub(String, 1, string.len(Start)) == Start
end

CommandManager:Module("Globals")