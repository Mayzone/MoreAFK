-- invisible player client/host created Playhouse/Mayzone
function update_invisible_state(state)
	local statetable = {
		"Standard",
		"Civilian",
		"MaskOff",
		"Clean",
		"BleedOut",
		"ParaChuting",
		"Incapacitated",
		"Carry",
		"Arrested",
	}
	if alive(managers.player:player_unit()) then
		for id,state_table in pairs(statetable) do
			Hooks:Add("Player"..state_table.."Update", "UpdateMovState"..id , function(t, dt)
				self:_upd_attention()
			end)
		end
		managers.player:player_unit():movement():set_attention_settings({state})
	end
end

global_invisible_toggle = global_invisible_toggle or false
if not global_invisible_toggle then
	BetterDelayedCalls:Add("invisible_persist", 0.2, function()
		update_invisible_state("pl_civilian")
	end, true)
	managers.mission._fading_debug_output:script().log('Invisible - ACTIVATED',  Color.green)
else
	update_invisible_state("pl_mask_on_foe_combatant_whisper_mode_stand")
	update_invisible_state("pl_mask_on_foe_combatant_whisper_mode_crouch")
	BetterDelayedCalls:Remove("invisible_persist")
	managers.mission._fading_debug_output:script().log('Invisible - DEACTIVATED',  Color.red)
end
global_invisible_toggle = not global_invisible_toggle